#include <fstream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

int main() {
    return 0;
}
